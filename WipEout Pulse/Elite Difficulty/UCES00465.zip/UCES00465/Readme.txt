WipEout Pulse | Elite Difficulty | UCES00465
--------------------------------------------

https://github.com/NR74W/WipEout-Mods

Description:
------------
A difficulty mod that improves the AI.

The mod is to be installed as DLC in `PSP/GAME/UCES00465`, and works with all versions of the game.


Filenames:
----------
OFFSET    NAMEHASH  METHOD  ORIG-SIZE -> COMP-SIZE  RATIO  FILENAME
========  ========  ======  =========    =========  =====  ========
00000080  cd86cf6a  zlib           58           60   103%  definition.xml
00000100  484ccf45  zlib         1339          337    25%  stringtable.xml
00000280  92fd271b  zlib         1372          472    34%  data/xml/airacestats_flash.xml
00000480  2f50879c  zlib         1374          474    34%  data/xml/airacestats_phantom.xml
00000680  1ca9f375  zlib         1373          469    34%  data/xml/airacestats_rapier.xml
00000880  6bce4338  zlib         1372          471    34%  data/xml/airacestats_venom.xml