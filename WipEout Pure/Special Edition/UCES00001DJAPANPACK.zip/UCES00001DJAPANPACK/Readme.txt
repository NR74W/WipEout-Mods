WipEout Pure | Japanese Language Pack | UCES00001DJAPANPACK
-----------------------------------------------------------

https://github.com/NR74W/WipEout-Mods

Description:
------------
Adds the official Japanese localization.

For use only with WipEout Pure: Special Edition.


Usage:
------
To use custom DLCs, the "Remove DLC Signature Check" cheat code created by thp (Thomas Perl) must be used:

_S UCES-00001
_G WipEout Pure (Europe)
_C1 Remove DLC Signature Check
_L 0x200A6FC0 0x00000000
_L 0x200A70A0 0x00000000

Signature used in the encrypted WAD: Voice Of Cod Music Pack (UCES00001DVOCMUSIC)


Notes:
------
This DLC can work with the original game.
However, the preview texture screen_JA_EU.mip of each skin does not exist in the retail version.
Each language has different preview textures used for the Skins screen. If one of them is missing and the game tries to access it, the game crashes.

The Japanese font files already exist in the European version, left unused.
For some reason, the textures are different from the JP version (UCJS-10007), the European version contains 34 additional Kanji characters.


Filenames:
----------
OFFSET    NAMEHASH  METHOD  ORIG-SIZE -> COMP-SIZE  RATIO  FILENAME
========  ========  ======  =========    =========  =====  ========
00000080  cd86cf6a  zlib        78900        17173    22%  definition.xml