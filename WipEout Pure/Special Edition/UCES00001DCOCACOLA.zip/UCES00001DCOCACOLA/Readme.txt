WipEout Pure | Coca-Cola Ships Pack | UCES00001DCOCACOLA
--------------------------------------------------------

https://github.com/NR74W/WipEout-Mods

Description:
------------
Replaces the standard ship with a Coca-Cola version for the original 8 teams. (From UCJS10007DCOCACOLA4)

Can be used with WipEout Pure: Special Edition or the original game.


Usage:
------
To use custom DLCs, the "Remove DLC Signature Check" cheat code created by thp (Thomas Perl) must be used:

_S UCES-00001
_G WipEout Pure (Europe)
_C1 Remove DLC Signature Check
_L 0x200A6FC0 0x00000000
_L 0x200A70A0 0x00000000


Notes:
------
Released exclusively in Japan, these promotional Coca-Cola ships were reskins for the 8 default teams in WipEout Pure.
Since they replace the original ships, it is not possible to have the default ships and the Coca-Cola skins available at the same time.


Filenames:
----------
OFFSET    NAMEHASH  METHOD  ORIG-SIZE -> COMP-SIZE  RATIO  FILENAME
========  ========  ======  =========    =========  =====  ========
00000180  cd86cf6a  zlib           79           77    97%  definition.xml
00000200  484ccf45  stored          0            0    ---  stringtable.xml
00000200  033f4a08  zlib        74576        25895    35%  data/ships/ag_systems/ship.vex
00006780  8d6c123b  zlib        30592        12955    42%  data/ships/ag_systems/shipwreck.vex
00009a80  fb23a8c0  zlib        56816        24182    43%  data/ships/assegai/ship.vex
0000f900  e1260933  zlib        33152        16033    48%  data/ships/assegai/shipwreck.vex
00013800  86f794bc  zlib        70800        28490    40%  data/ships/auricom/ship.vex
0001a780  77e8d9b3  zlib        27728        12788    46%  data/ships/auricom/shipwreck.vex
0001d980  934e8d3d  zlib        60336        23492    39%  data/ships/feisar/ship.vex
00023580  2b457b0f  zlib        22144        10981    50%  data/ships/feisar/shipwreck.vex
00026080  1aac594a  zlib        65808        24619    37%  data/ships/harimau/ship.vex
0002c100  89a64ed2  zlib        23360        11450    49%  data/ships/harimau/shipwreck.vex
0002ee00  38842a96  zlib        68128        26888    39%  data/ships/piranha/ship.vex
00035780  2dc58280  zlib        22816        10980    48%  data/ships/piranha/shipwreck.vex
00038280  38da96c4  zlib        62512        23753    38%  data/ships/qirex/ship.vex
0003df80  5e90ecb3  zlib        24784        11006    44%  data/ships/qirex/shipwreck.vex
00040a80  25dfa124  zlib        65280        24649    38%  data/ships/triakis/ship.vex
00046b00  e21f4583  zlib        26592        12927    49%  data/ships/triakis/shipwreck.vex