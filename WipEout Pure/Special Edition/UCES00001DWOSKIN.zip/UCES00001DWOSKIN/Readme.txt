WipEout Pure | WipEout Skins Pack | UCES00001DWOSKIN
----------------------------------------------------

https://github.com/NR74W/WipEout-Mods

Description:
------------
Contains 4 custom menu skins (WipEout / WipEout 2097 / Wip3out / WipEout Fusion).

Can be used with WipEout Pure: Special Edition or the original game.


Usage:
------
To use custom DLCs, the "Remove DLC Signature Check" cheat code created by thp (Thomas Perl) must be used:

_S UCES-00001
_G WipEout Pure (Europe)
_C1 Remove DLC Signature Check
_L 0x200A6FC0 0x00000000
_L 0x200A70A0 0x00000000

Signature used in the encrypted WAD: Sci-Fi Pack (UCES00001DSCIFIPAK)


Filenames:
----------
OFFSET    NAMEHASH  METHOD  ORIG-SIZE -> COMP-SIZE  RATIO  FILENAME
========  ========  ======  =========    =========  =====  ========
00000300  cd86cf6a  zlib          519          183    35%  definition.xml
00000400  484ccf45  zlib          755          253    34%  stringtable.xml
00000500  3ef5df8a  zlib          925          317    34%  data/skins/wipeout/screen.xml
00000680  116e1ca9  zlib         5085         1107    22%  data/skins/wipeout/skin.xml
00000b00  a3b619ed  zlib       263184       139583    53%  data/skins/wipeout/images/background.mip
00022c80  3a8b3016  zlib        33808        17088    51%  data/skins/wipeout/images/screen.mip
00026f80  80697de2  zlib        33808        17074    51%  data/skins/wipeout/images/screen_de_eu.mip
0002b280  ca7875f7  zlib        33808        17010    50%  data/skins/wipeout/images/screen_en_eu.mip
0002f500  2dc6510d  zlib        33808        17292    51%  data/skins/wipeout/images/screen_es_eu.mip
00033900  d8e16d56  zlib        33808        17155    51%  data/skins/wipeout/images/screen_fr_eu.mip
00037c80  c137ab00  zlib        33808        16911    50%  data/skins/wipeout/images/screen_it_eu.mip
0003bf00  cce1a88a  zlib        33808        17180    51%  data/skins/wipeout/images/screen_ja_eu.mip
00040280  5eb2bf5e  zlib         9232         2739    30%  data/skins/wipeout/images/texture.mip
00040d80  2891f7a2  zlib          930          322    35%  data/skins/wipeout_2097/screen.xml
00040f00  9b3eeee4  zlib         5097         1113    22%  data/skins/wipeout_2097/skin.xml
00041380  7838dc5f  zlib       263184        17968     7%  data/skins/wipeout_2097/images/background.mip
00045a00  34e61978  zlib        33808        10310    30%  data/skins/wipeout_2097/images/screen.mip
00048280  bd945c69  zlib        33808        10336    31%  data/skins/wipeout_2097/images/screen_de_eu.mip
0004ab00  f785547c  zlib        33808        10310    30%  data/skins/wipeout_2097/images/screen_en_eu.mip
0004d380  103b7086  zlib        33808        10492    31%  data/skins/wipeout_2097/images/screen_es_eu.mip
0004fc80  e51c4cdd  zlib        33808        10093    30%  data/skins/wipeout_2097/images/screen_fr_eu.mip
00052400  fcca8a8b  zlib        33808        10582    31%  data/skins/wipeout_2097/images/screen_it_eu.mip
00054d80  f11c8901  zlib        33808        10241    30%  data/skins/wipeout_2097/images/screen_ja_eu.mip
00057600  f4b69e28  zlib         9232         3236    35%  data/skins/wipeout_2097/images/texture.mip
00058300  9296ef4a  zlib          925          317    34%  data/skins/wip3out/screen.xml
00058480  b801f405  zlib         5047         1111    22%  data/skins/wip3out/skin.xml
00058900  2bc30310  zlib        33808         5752    17%  data/skins/wip3out/images/screen.mip
00059f80  f3f5e53c  zlib        33808         5761    17%  data/skins/wip3out/images/screen_de_eu.mip
0005b680  b9e4ed29  zlib        33808         5752    17%  data/skins/wip3out/images/screen_en_eu.mip
0005cd00  5e5ac9d3  zlib        33808         5934    18%  data/skins/wip3out/images/screen_es_eu.mip
0005e480  ab7df588  zlib        33808         5554    16%  data/skins/wip3out/images/screen_fr_eu.mip
0005fa80  b2ab33de  zlib        33808         6206    18%  data/skins/wip3out/images/screen_it_eu.mip
00061300  bf7d3054  zlib        33808         5701    17%  data/skins/wip3out/images/screen_ja_eu.mip
00062980  b7c05258  zlib         9232         1708    19%  data/skins/wip3out/images/texture.mip
00063080  45423fe0  zlib          932          322    35%  data/skins/wipeout_fusion/screen.xml
00063200  6c1fc9ec  zlib         5101         1138    22%  data/skins/wipeout_fusion/skin.xml
00063680  fb10fab2  zlib       263184        34543    13%  data/skins/wipeout_fusion/images/background.mip
0006bd80  1dd0cba6  zlib        33808        11131    33%  data/skins/wipeout_fusion/images/screen.mip
0006e900  8449d71d  zlib        33808        11180    33%  data/skins/wipeout_fusion/images/screen_de_eu.mip
00071500  ce58df08  zlib        33808        11131    33%  data/skins/wipeout_fusion/images/screen_en_eu.mip
00074080  29e6fbf2  zlib        33808        11400    34%  data/skins/wipeout_fusion/images/screen_es_eu.mip
00076d80  dcc1c7a9  zlib        33808        10937    32%  data/skins/wipeout_fusion/images/screen_fr_eu.mip
00079880  c51701ff  zlib        33808        11490    34%  data/skins/wipeout_fusion/images/screen_it_eu.mip
0007c580  c8c10275  zlib        33808        11128    33%  data/skins/wipeout_fusion/images/screen_ja_eu.mip
0007f100  95f45729  zlib         9232         2836    31%  data/skins/wipeout_fusion/images/texture.mip