WipEout Pure | HUD Pack | UCES00001DHUDPACK
-------------------------------------------

https://github.com/NR74W/WipEout-Mods

Description:
------------
Reduces the size of the HUD elements to a minimum.

Can be used with WipEout Pure: Special Edition or the original game.


Usage:
------
To use custom DLCs, the "Remove DLC Signature Check" cheat code created by thp (Thomas Perl) must be used:

_S UCES-00001
_G WipEout Pure (Europe)
_C1 Remove DLC Signature Check
_L 0x200A6FC0 0x00000000
_L 0x200A70A0 0x00000000


Notes:
------
The idea was to make the HUD less cluttered, with more space for the gameplay.

The characters "/" and "Lap out of" are slighly shifted to the right after the first lap, because the character "1" is smaller than the other numbers.
This was originally done for the large font size used on the HUD, but with a smaller size there is some space between the lap number and "/(Lap OutOf)". It is not possible to correct this.


Filenames:
----------
OFFSET    NAMEHASH  METHOD  ORIG-SIZE -> COMP-SIZE  RATIO  FILENAME
========  ========  ======  =========    =========  =====  ========
00000080  033be1f1  zlib         9978         1325    13%  data/xml/arcade_hud.xml
00000600  57810fd5  zlib         8417         1204    14%  data/xml/timetrial_hud.xml
00000b00  cce09c29  zlib         4006          761    19%  data/xml/zone_hud.xml
00000e00  357fbe81  zlib         1136          420    37%  data/hud/zone_bar_2.vex