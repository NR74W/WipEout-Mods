WipEout Pure | Zone Pack | UCES00001DZONEPACK
---------------------------------------------

https://github.com/NR74W/WipEout-Mods

Description:
------------
Adds the Zone League (Pro Tozo / Mallavol / Corridon 12 / Syncopia).

Can be used with WipEout Pure: Special Edition or the original game.


Usage:
------
To use custom DLCs, the "Remove DLC Signature Check" cheat code created by thp (Thomas Perl) must be used:

_S UCES-00001
_G WipEout Pure (Europe)
_C1 Remove DLC Signature Check
_L 0x200A6FC0 0x00000000
_L 0x200A70A0 0x00000000

Signature used in the encrypted WAD: Oblivion Music Pack (UCES00001DOBLIVION)


Notes:
------
The game randomly freezes on Corridon 12 in Single Race. This only happens when there are AI ships, not in Time Trial / Free Play.
This DLC should be used at the player's own risk, it is best to play on this track only in the Time Trial and Free Play modes.
The Zone League cannot be added for Tournament mode, for some reason the medals for that tournament are already earned even if a new profile is created.

Corridon 12 was originally named "Coridon 12" in WipEout Pure.
The track name was changed in WipEout HD Fury, but it is not known why. It has been corrected in the hack as it seems to be the official name.


Filenames:
----------
OFFSET    NAMEHASH  METHOD  ORIG-SIZE -> COMP-SIZE  RATIO  FILENAME
========  ========  ======  =========    =========  =====  ========
00000180  cd86cf6a  zlib          724          229    32%  definition.xml
00000280  484ccf45  zlib         6504         1536    24%  stringtable.xml
00000880  8547ae2e  zlib        66576         3288     5%  data/tournaments/zone/images/zoneleague.mip
00001580  4dc93f6a  zlib        33808         2761     8%  data/tournaments/zone/images/zoneleague_m.mip
00002080  6181b28b  zlib          443          262    59%  data/tournaments/zone/screen.xml
00002200  d266e22e  zlib          670          343    51%  data/tournaments/zone/screen_m.xml
00002380  d07654cb  zlib         3801          720    19%  data/zone/01_zone/screen.xml
00002680  6b765b91  zlib         1145          310    27%  data/zone/01_zone/screen_m.xml
00002800  aa8f93ea  zlib         4436          817    18%  data/zone/01_zone/screen_tt.xml
00002b80  83ec0f4f  zlib         3801          719    19%  data/zone/02_zone/screen.xml
00002e80  c820dd38  zlib         1145          310    27%  data/zone/02_zone/screen_m.xml
00003000  0526de20  zlib         4436          816    18%  data/zone/02_zone/screen_tt.xml
00003380  044ac40c  zlib         3801          720    19%  data/zone/03_zone/screen.xml
00003680  1fc25d60  zlib         1145          310    27%  data/zone/03_zone/screen_m.xml
00003800  6041e566  zlib         4436          817    18%  data/zone/03_zone/screen_tt.xml
00003b80  24d8b847  zlib         3801          720    19%  data/zone/04_zone/screen.xml
00003e80  55fcd62b  zlib         1145          310    27%  data/zone/04_zone/screen_m.xml
00004000  810543f5  zlib         4436          817    18%  data/zone/04_zone/screen_tt.xml