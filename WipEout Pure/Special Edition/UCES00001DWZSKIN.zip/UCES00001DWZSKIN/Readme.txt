WipEout Pure | WipEoutZone Skin Pack | UCES00001DWZSKIN
-------------------------------------------------------

https://github.com/NR74W/WipEout-Mods

Description:
------------
Adds a skin inspired by the WipEoutZone website.
Based on the idea of a fan from WipEoutZone in 2005: https://www.wipeoutzone.com/forum/showthread.php?2809-WipeoutZonE-Skin

Can be used with WipEout Pure: Special Edition or the original game.


Usage:
------
To use custom DLCs, the "Remove DLC Signature Check" cheat code created by thp (Thomas Perl) must be used:

_S UCES-00001
_G WipEout Pure (Europe)
_C1 Remove DLC Signature Check
_L 0x200A6FC0 0x00000000
_L 0x200A70A0 0x00000000


Filenames:
----------
OFFSET    NAMEHASH  METHOD  ORIG-SIZE -> COMP-SIZE  RATIO  FILENAME
========  ========  ======  =========    =========  =====  ========
00000100  cd86cf6a  zlib          191          151    79%  definition.xml
00000200  484ccf45  zlib          182          144    79%  stringtable.xml
00000300  b079248d  zlib          929          320    34%  data/skins/wipeoutzone/screen.xml
00000480  ddfc6285  zlib         5095         1111    22%  data/skins/wipeoutzone/skin.xml
00000900  a4f11fb3  zlib       263184         2396     1%  data/skins/wipeoutzone/images/background.mip
00001280  f9e97bd9  zlib        33808         5416    16%  data/skins/wipeoutzone/images/screen.mip
00002800  4d32af4a  zlib        33808         5422    16%  data/skins/wipeoutzone/images/screen_de_eu.mip
00003d80  0723a75f  zlib        33808         5416    16%  data/skins/wipeoutzone/images/screen_en_eu.mip
00005300  e09d83a5  zlib        33808         5590    17%  data/skins/wipeoutzone/images/screen_es_eu.mip
00006900  15babffe  zlib        33808         5179    15%  data/skins/wipeoutzone/images/screen_fr_eu.mip
00007d80  0c6c79a8  zlib        33808         5861    17%  data/skins/wipeoutzone/images/screen_it_eu.mip
00009480  01ba7a22  zlib        33808         5476    16%  data/skins/wipeoutzone/images/screen_ja_eu.mip
0000aa00  55aa0234  zlib         9232         2865    31%  data/skins/wipeoutzone/images/texture.mip